// Aurora Dev: sample HTML template for Folio.
// Templates can use JavaScript. It runs in a sandbox: it can change the page, but it
// can't make network requests, use cookies or localStorage, or reach Folio itself.
(function () {
  var root = document.documentElement;
  root.classList.add("js");

  // window.FOLIO holds the person's details, if you'd rather work with data in JS.
  var data = window.FOLIO || {};
  if (data.name) document.title = data.name + (data.headline ? " · " + data.headline : "");

  // Dark / light switch (not remembered between visits: storage isn't available here).
  var toggle = document.getElementById("theme");
  if (toggle) {
    toggle.addEventListener("click", function () {
      var light = root.getAttribute("data-theme") === "light";
      root.setAttribute("data-theme", light ? "dark" : "light");
      toggle.setAttribute("aria-pressed", String(!light));
    });
  }

  // Fade items in as they scroll into view.
  var items = Array.prototype.slice.call(document.querySelectorAll(".reveal"));
  if ("IntersectionObserver" in window) {
    var seen = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          entry.target.classList.add("in");
          seen.unobserve(entry.target);
        }
      });
    }, { threshold: 0.12 });
    items.forEach(function (item) { seen.observe(item); });
  } else {
    items.forEach(function (item) { item.classList.add("in"); });
  }

  // Highlight the current section in the menu.
  var links = Array.prototype.slice.call(document.querySelectorAll(".nav nav a"));
  var sections = links
    .map(function (link) { return document.querySelector(link.getAttribute("href")); })
    .filter(Boolean);
  if ("IntersectionObserver" in window && sections.length) {
    var current = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (!entry.isIntersecting) return;
        links.forEach(function (link) {
          link.classList.toggle("active", link.getAttribute("href") === "#" + entry.target.id);
        });
      });
    }, { rootMargin: "-45% 0px -50% 0px" });
    sections.forEach(function (section) { current.observe(section); });
  }
})();
