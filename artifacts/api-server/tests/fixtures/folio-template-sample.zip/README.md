# Aurora Dev: sample HTML template for Folio

Edit these files, zip them, and upload the ZIP in **Admin → Templates**. See `TEMPLATES_GUIDE.md` in the Folio project for the full rules.

## Files

| File | Purpose |
|---|---|
| `folio-template.json` | **Required.** The template's id, name, description and category |
| `index.html` | **Required.** The page. `{{placeholders}}` are replaced with each person's details |
| `style.css`, `script.js` | Your CSS and JavaScript. Link them normally; Folio bundles them |
| `assets/` | Images and fonts (png, jpg, svg, webp, woff2…). Reference them with relative paths |

## The manifest (`folio-template.json`)

```json
{
  "id": "aurora-dev",
  "name": "Aurora Dev",
  "description": "One sentence for the gallery.",
  "category": "developers",
  "premium": false,
  "recommendedFor": ["Software Developer"]
}
```

`category` can be `developers`, `designers`, `writers`, `marketers`, `teachers`, `healthcare`, `lawyers`… or an exact Folio category. Folio files the template in that category and decides whether it's Technical or Non-technical.

## Placeholders

| Placeholder | Meaning |
|---|---|
| `{{name}}` `{{firstName}}` `{{initials}}` | The person's name |
| `{{headline}}` `{{summary}}` `{{location}}` `{{profession}}` | Text details |
| `{{email}}` `{{emailLink}}` `{{phone}}` `{{phoneLink}}` | Contact (`…Link` is ready for `href`) |
| `{{avatar}}` | Photo address (empty when there isn't one) |
| `{{links.github}}` `{{links.linkedin}}` `{{links.twitter}}` `{{links.website}}` | Profile links (empty when not set) |
| `{{#experience}}…{{/experience}}` | Repeats for each role: `{{role}}` `{{company}}` `{{period}}` `{{description}}` |
| `{{#education}}…{{/education}}` | `{{degree}}` `{{school}}` `{{period}}` |
| `{{#projects}}…{{/projects}}` | `{{name}}` `{{description}}` `{{liveUrl}}` `{{githubUrl}}`, and `{{#technologies}}{{.}}{{/technologies}}` |
| `{{#skills}}{{.}}{{/skills}}` | Each skill |
| `{{#x}}…{{/x}}` | Shows only if `x` has a value; `{{^x}}…{{/x}}` shows only if it doesn't |
| `{{hasProjects}}` `{{hasExperience}}` `{{hasEducation}}` `{{hasSkills}}` `{{hasLinks}}` | True when there's something to show |
| `{{year}}` | The current year |

Everything is HTML-escaped, so a person's text can't break the page. In JavaScript, the same data is in `window.FOLIO`.
